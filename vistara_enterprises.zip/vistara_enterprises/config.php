<?php
$con = mysqli_connect("localhost","root","","vistara_enterprises");
// live
// $con = mysql_connect("localhost","root","","vistara_enterprises");

?>